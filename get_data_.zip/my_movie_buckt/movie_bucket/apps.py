from django.apps import AppConfig


class MovieBucketConfig(AppConfig):
    name = 'movie_bucket'
